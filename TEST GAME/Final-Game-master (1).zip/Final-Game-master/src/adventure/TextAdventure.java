package adventure;

public class TextAdventure {
    private static AdventureModel model = new AdventureModel();

    public static void main(String[] args) {
        model.playGame();
    }
}
