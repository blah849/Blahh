package adventure.things.interactive;

import adventure.things.Thing;

public class Knife extends Thing {
    public Knife() {
        shortName = "Knife";
        fullName = "Knife";
        description = "It's a common knife, it looks sharp";
    }
}
