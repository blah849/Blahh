package adventure.things.generic;

import adventure.things.Thing;

public class Couch extends Thing {
    public Couch() {
        shortName = "Couch";
        fullName = "Couch";
    }
}
