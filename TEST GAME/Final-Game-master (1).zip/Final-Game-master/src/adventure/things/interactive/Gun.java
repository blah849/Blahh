package adventure.things.interactive;

import adventure.things.Thing;

public class Gun extends Thing {
    public Gun() {
        shortName = "Gun";
        fullName = "Gun";
        description = "It looks like a real weapon";
    }
}
