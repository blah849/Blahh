package adventure.things.interactive;

import adventure.things.Thing;

public class Ammunition extends Thing {
    public Ammunition() {
        shortName = "Ammunition";
        fullName = "Ammunition";
        description = "It's typical pistol ammo.";
    }
}
