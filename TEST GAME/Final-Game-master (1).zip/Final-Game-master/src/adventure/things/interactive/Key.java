package adventure.things.interactive;

import adventure.things.Thing;

public class Key extends Thing {
    public Key() {
        shortName = "Key";
        fullName = "Key";
        description = "This key might come in handy later.";
    }
}
