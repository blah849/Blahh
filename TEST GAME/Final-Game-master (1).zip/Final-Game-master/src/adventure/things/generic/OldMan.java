package adventure.things.generic;

import adventure.things.Thing;

public class OldMan extends Thing {
    public OldMan() {
        shortName = "Old man";
        fullName = "Old man";
        description = "If you want to stay safe don’t go to the west hallway,\n" +
                "there are some bad people that live over there.";
    }
}
